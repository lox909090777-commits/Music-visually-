package com.example.musicviz

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 140, 48, 48)
        }
        fun btn(t: String, f: () -> Unit) {
            col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }
        col.addView(TextView(this).apply {
            text = "1. Запустите захват звука.\n2. В системном окне выберите «Весь экран».\n3. Добавьте виджет MusicViz на рабочий стол и включите музыку."
            textSize = 16f
            setPadding(0, 0, 0, 32)
        })
        btn("Запустить захват звука") { startCapture() }
        btn("Добавить виджет на рабочий стол") {
            val awm = getSystemService(AppWidgetManager::class.java)
            if (awm.isRequestPinAppWidgetSupported) {
                awm.requestPinAppWidget(ComponentName(this, VizWidget::class.java), null, null)
            } else {
                Toast.makeText(this, "Долгое нажатие на рабочем столе → Виджеты → MusicViz", Toast.LENGTH_LONG).show()
            }
        }
        btn("Остановить") { stopService(Intent(this, CaptureService::class.java)) }
        setContentView(col)
    }

    private fun startCapture() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val perms = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.RECORD_AUDIO)
            requestPermissions(perms, 1)
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startCapture()
        else Toast.makeText(this, "Нужно разрешение на запись звука", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
            )
        }
    }
}
