package com.example.musicviz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.widget.RemoteViews
import kotlin.math.*

/** Общий спектр: сервис пишет, обои читают. */
object Spectrum {
    const val BANDS = 32
    @Volatile var bands = FloatArray(BANDS)
}

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    @Volatile private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("viz", "Визуализатор", NotificationManager.IMPORTANCE_LOW))
        val note = Notification.Builder(this, "viz")
            .setContentTitle("Визуализатор музыки работает")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)
        projection = proj

        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(44100)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val rec = AudioRecord.Builder()
            .setAudioFormat(fmt)
            .setBufferSizeInBytes(8192)
            .setAudioPlaybackCaptureConfig(cfg)
            .build()
        rec.startRecording()
        record = rec
        running = true
        Thread { loop(rec) }.start()
        return START_NOT_STICKY
    }

    private fun loop(rec: AudioRecord) {
        val n = 1024
        val buf = ShortArray(n)
        val re = FloatArray(n)
        val im = FloatArray(n)
        val smooth = FloatArray(Spectrum.BANDS)
        var last = 0L
        var quiet = false
        while (running) {
            val r = rec.read(buf, 0, n)
            if (r <= 0) break
            for (i in 0 until n) {
                val window = 0.5f - 0.5f * cos(2f * PI.toFloat() * i / n)
                re[i] = if (i < r) buf[i] / 32768f * window else 0f
                im[i] = 0f
            }
            fft(re, im)
            val out = FloatArray(Spectrum.BANDS)
            for (b in 0 until Spectrum.BANDS) {
                val lo = (1 + (b.toDouble() / Spectrum.BANDS).pow(2.0) * 250).toInt()
                val hi = max(lo + 1, (1 + ((b + 1).toDouble() / Spectrum.BANDS).pow(2.0) * 250).toInt())
                var m = 0f
                for (k in lo until hi) m = max(m, hypot(re[k], im[k]))
                val db = 20f * log10(m + 1e-6f)
                val v = ((db + 70f) / 60f).coerceIn(0f, 1f)
                smooth[b] = if (v > smooth[b]) v else smooth[b] * 0.85f + v * 0.15f
                out[b] = smooth[b]
            }
            Spectrum.bands = out
            val now = SystemClock.uptimeMillis()
            if (now - last >= 100) {
                last = now
                val loud = out.max() > 0.02f
                if ((loud || !quiet) && getSystemService(PowerManager::class.java).isInteractive) {
                    pushWidget(out)
                    quiet = !loud
                }
            }
        }
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val t = re[i]; re[i] = re[j]; re[j] = t
                val u = im[i]; im[i] = im[j]; im[j] = u
            }
        }
        var len = 2
        while (len <= n) {
            val ang = (-2 * PI / len).toFloat()
            val wr = cos(ang)
            val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k
                    val b = a + len / 2
                    val xr = re[b] * cr - im[b] * ci
                    val xi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - xr; im[b] = im[a] - xi
                    re[a] += xr; im[a] += xi
                    val t = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = t
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun pushWidget(b: FloatArray) {
        try {
            val awm = AppWidgetManager.getInstance(this)
            val ids = awm.getAppWidgetIds(ComponentName(this, VizWidget::class.java))
            if (ids.isEmpty()) return
            val o = awm.getAppWidgetOptions(ids[0])
            val d = resources.displayMetrics.density * 0.5f
            val w = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250) * d).toInt().coerceIn(120, 400)
            val h = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110) * d).toInt().coerceIn(60, 200)
            val rv = RemoteViews(packageName, R.layout.widget)
            rv.setImageViewBitmap(R.id.img, Viz.render(b, w, h))
            awm.partiallyUpdateAppWidget(ids, rv)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        running = false
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        projection?.stop()
        Spectrum.bands = FloatArray(Spectrum.BANDS)
        pushWidget(Spectrum.bands)
        super.onDestroy()
    }
}
