package com.example.musicviz

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

object Viz {
    /** Рисует столбики, расходящиеся от центральной линии. */
    fun render(bands: FloatArray, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.argb(215, 12, 12, 24)
        c.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), h * 0.2f, h * 0.2f, paint)
        val n = bands.size
        val pad = w * 0.07f
        val gap = w * 0.008f
        val bw = (w - 2 * pad - gap * (n - 1)) / n
        val mid = h / 2f
        val maxH = h * 0.36f
        for (i in 0 until n) {
            val bh = maxH * bands[i] + 3f
            val x = pad + i * (bw + gap)
            paint.color = Color.HSVToColor(floatArrayOf(190f + 150f * i / n, 0.75f, 1f))
            c.drawRoundRect(x, mid - bh, x + bw, mid + bh, bw / 2, bw / 2, paint)
        }
        return bmp
    }
}
